package com.bala.student.service;

import org.springframework.stereotype.Repository;


@Repository
public class LoginRepository {

	
}
