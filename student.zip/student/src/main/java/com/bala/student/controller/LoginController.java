package com.bala.student.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class LoginController {

	@GetMapping({"/","/login"})
	public ModelAndView singIn() {
		System.out.println("Bala ");
		return new ModelAndView("login");

	}

	@PostMapping("loginValidation")
	public ModelAndView loginValidation() {
		System.out.println("Bala ");
		return new ModelAndView("login");

	}
}
